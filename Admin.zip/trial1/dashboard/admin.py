from django.contrib import admin
from .models import Line,Route,Station
# Register your models here.

admin.site.register(Line)
admin.site.register(Route)
admin.site.register(Station)